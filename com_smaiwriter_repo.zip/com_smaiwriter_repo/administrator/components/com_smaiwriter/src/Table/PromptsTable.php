<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Smaiwriter\Administrator\Table;

defined('_JEXEC') or die;

use Joomla\CMS\Table\Table;

/**
 * Table class for prompts queue.
 */
class PromptsTable extends Table
{
    /**
     * Constructor.
     *
     * @param   \JDatabaseDriver  $db  Database driver
     */
    public function __construct($db)
    {
        parent::__construct('#__smaiwriter_prompts', 'id', $db);
    }
}
