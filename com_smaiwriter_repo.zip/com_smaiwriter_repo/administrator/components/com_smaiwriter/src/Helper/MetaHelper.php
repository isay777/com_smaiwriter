<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Smaiwriter\Helper;

defined('_JEXEC') or die;

/**
 * Helper class for parsing meta title and description from AI response.
 */
class MetaHelper
{
    /**
     * Parse meta title and description from AI generated text.
     *
     * @param   string  $text  Response text from AI containing 'TITLE:' and 'DESCRIPTION:'
     *
     * @return  array   ['title' => string, 'desc' => string]
     */
    public static function parseMeta($text)
    {
        $meta = [
            'title' => '',
            'desc'  => ''
        ];
        if (preg_match('/TITLE[:\- ]+(.*)/i', $text, $m)) {
            $meta['title'] = trim($m[1]);
        }
        if (preg_match('/DESCRIPTION[:\- ]+(.*)/i', $text, $m)) {
            $meta['desc'] = trim($m[1]);
        }
        return $meta;
    }
}
