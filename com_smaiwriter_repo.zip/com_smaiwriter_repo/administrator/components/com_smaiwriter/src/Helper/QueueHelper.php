<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Smaiwriter\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

/**
 * Helper class for managing the generation queue.
 */
class QueueHelper
{
    /**
     * Add multiple prompts to the queue as pending tasks.
     *
     * @param   array  $prompts  List of prompts to register
     *
     * @return  void
     */
    public static function addPrompts(array $prompts)
    {
        $db = Factory::getDbo();
        foreach ($prompts as $prompt) {
            $prompt = trim($prompt);
            if ($prompt === '') {
                continue;
            }

            $query = $db->getQuery(true)
                ->insert($db->quoteName('#__smaiwriter_prompts'))
                ->columns([
                    $db->quoteName('prompt'),
                    $db->quoteName('status'),
                    $db->quoteName('created_at'),
                    $db->quoteName('updated_at')
                ])
                ->values(
                    $db->quote($prompt) . ', ' .
                    $db->quote('pending') . ', ' .
                    $db->quote(date('Y-m-d H:i:s')) . ', ' .
                    $db->quote(date('Y-m-d H:i:s'))
                );

            $db->setQuery($query)->execute();
        }
    }
}
