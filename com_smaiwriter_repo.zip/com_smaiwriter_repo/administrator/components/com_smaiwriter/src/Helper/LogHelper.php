<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Smaiwriter\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

/**
 * Helper class to record log entries.
 */
class LogHelper
{
    /**
     * Record a log entry into the database table.
     *
     * @param   string  $type    Type of log entry (e.g., 'text', 'image', 'meta', 'task')
     * @param   string  $status  Status (e.g., 'success', 'error')
     * @param   string  $message Message text
     * @param   string  $prompt  Related prompt or context
     *
     * @return  void
     */
    public static function add($type, $status, $message, $prompt = '')
    {
        $db = Factory::getDbo();
        $query = $db->getQuery(true);

        $query
            ->insert($db->quoteName('#__smaiwriter_logs'))
            ->columns(
                [
                    $db->quoteName('type'),
                    $db->quoteName('status'),
                    $db->quoteName('message'),
                    $db->quoteName('prompt'),
                    $db->quoteName('created_at')
                ]
            )
            ->values(
                $db->quote($type) . ', ' .
                $db->quote($status) . ', ' .
                $db->quote($message) . ', ' .
                $db->quote($prompt) . ', ' .
                $db->quote(date('Y-m-d H:i:s'))
            );

        $db->setQuery($query)->execute();
    }
}
