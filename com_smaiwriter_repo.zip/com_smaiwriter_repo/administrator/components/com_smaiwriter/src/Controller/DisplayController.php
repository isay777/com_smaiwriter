<?php

namespace Joomla\Component\Smaiwriter\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Контроллер отображения по умолчанию
 */
class DisplayController extends BaseController
{
    /**
     * @var string
     */
    protected $default_view = 'dashboard';
}