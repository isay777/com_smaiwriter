<?php

namespace Joomla\Component\Smaiwriter\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;

/**
 * Контроллер для AJAX-запросов
 */
class AjaxController extends BaseController
{
    /**
     * Возвратить данные для прогрессбара в JSON
     */
    public function progress()
    {
        $db = Factory::getDbo();
        $total      = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts")->loadResult();
        $pending    = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts WHERE status='pending'")->loadResult();
        $inprogress = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts WHERE status='inprogress'")->loadResult();
        $success    = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts WHERE status='success'")->loadResult();
        $error      = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts WHERE status='error'")->loadResult();
        $skipped    = (int) $db->setQuery("SELECT COUNT(*) FROM #__smaiwriter_prompts WHERE status='skipped'")->loadResult();

        $current = $db->setQuery(
            "SELECT prompt FROM #__smaiwriter_prompts WHERE status='inprogress' ORDER BY updated_at DESC LIMIT 1"
        )->loadResult();

        $processed = $success + $error + $skipped;
        $percent   = $total > 0 ? round(($processed / $total) * 100) : 0;

        echo json_encode([
            'total'      => $total,
            'pending'    => $pending,
            'inprogress' => $inprogress,
            'success'    => $success,
            'error'      => $error,
            'skipped'    => $skipped,
            'percent'    => $percent,
            'current'    => $current ?: '',
        ]);
        exit;
    }
}