<?php

namespace Joomla\Component\Smaiwriter\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;

/**
 * Контроллер управления задачами очереди
 */
class TasksController extends BaseController
{
    /**
     * Пометить задачу как «пропущенная»
     */
    public function skip()
    {
        $id = $this->input->getInt('id');
        $db = Factory::getDbo();
        $db->setQuery(
            "UPDATE #__smaiwriter_prompts SET status='skipped', updated_at=NOW() WHERE id=" . (int) $id
        )->execute();
        $this->setRedirect('index.php?option=com_smaiwriter&view=tasks', 'Задача помечена как пропущенная');
    }
}