<?php

namespace Joomla\Component\Smaiwriter\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Контроллер генерации материалов
 */
class GenerateController extends BaseController
{
    /**
     * Запуск пакетной генерации
     */
    public function run()
    {
        $model = $this->getModel('Generate');
        // количество задач в одном запуске можно вынести в настройки
        $model->generateBatch(3);
        $this->setRedirect('index.php?option=com_smaiwriter&view=tasks', 'Генерация началась');
    }

    /**
     * Запуск одиночной генерации (используется кнопкой редактора)
     */
    public function single()
    {
        $prompt = $this->input->getString('prompt', '');
        $model  = $this->getModel('Generate');
        $model->generateSingle($prompt);
        echo json_encode(['success' => true]);
        exit;
    }
}