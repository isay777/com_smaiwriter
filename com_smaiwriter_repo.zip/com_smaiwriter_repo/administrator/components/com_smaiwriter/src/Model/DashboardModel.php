<?php

namespace Joomla\Component\Smaiwriter\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;

/**
 * Модель панели управления
 */
class DashboardModel extends BaseDatabaseModel
{
}