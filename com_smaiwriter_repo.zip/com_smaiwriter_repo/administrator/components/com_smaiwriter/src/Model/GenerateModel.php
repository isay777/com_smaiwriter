<?php

namespace Joomla\Component\Smaiwriter\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use Joomla\String\StringHelper;

use Smaiwriter\Helper\LogHelper;
use Smaiwriter\Helper\QueueHelper;
use Smaiwriter\Helper\ImageHelper;
use Smaiwriter\Helper\MetaHelper;

/**
 * Модель генерации контента
 */
class GenerateModel extends AdminModel
{
    /**
     * Выполнить пакетную генерацию N задач
     *
     * @param int $count
     * @return void
     */
    public function generateBatch($count = 3)
    {
        $db = Factory::getDbo();
        $tasks = $db->setQuery(
            "SELECT * FROM #__smaiwriter_prompts WHERE status='pending' ORDER BY id ASC LIMIT " . (int) $count
        )->loadAssocList();

        if (!$tasks) {
            LogHelper::add('batch', 'success', 'Нет задач для обработки');
            return;
        }
        foreach ($tasks as $task) {
            $this->processTask($task);
        }
    }

    /**
     * Сгенерировать единственную задачу (по нажатию кнопки)
     *
     * @param string $prompt
     * @return void
     */
    public function generateSingle($prompt)
    {
        if (!trim($prompt)) {
            return;
        }
        // добавляем в очередь
        QueueHelper::addPrompts([$prompt]);
        // получаем добавленную строку
        $db   = Factory::getDbo();
        $task = $db->setQuery(
            "SELECT * FROM #__smaiwriter_prompts ORDER BY id DESC LIMIT 1"
        )->loadAssoc();
        $this->processTask($task);
    }

    /**
     * Выполнить одну задачу (обновляет статус и логирует)
     *
     * @param array $task
     * @return void
     */
    private function processTask($task)
    {
        $db     = Factory::getDbo();
        $id     = (int) $task['id'];
        $prompt = $task['prompt'];
        // помечаем как inprogress
        $db->setQuery("UPDATE #__smaiwriter_prompts SET status='inprogress', updated_at=NOW() WHERE id={$id}")->execute();
        try {
            $articleId = $this->generateArticleFull($prompt);
            $db->setQuery(
                "UPDATE #__smaiwriter_prompts SET status='success', result_article_id=" . (int) $articleId . ", updated_at=NOW() WHERE id={$id}"
            )->execute();
            LogHelper::add('task', 'success', 'Задача выполнена', $prompt);
        } catch (\Throwable $e) {
            $db->setQuery(
                "UPDATE #__smaiwriter_prompts SET status='error', message=" . $db->quote($e->getMessage()) . ", updated_at=NOW() WHERE id={$id}"
            )->execute();
            LogHelper::add('task', 'error', $e->getMessage(), $prompt);
        }
    }

    /**
     * Полный цикл генерации: текст, изображение, meta и создание статьи
     *
     * @param string $prompt
     * @return int ID созданной статьи
     */
    private function generateArticleFull($prompt)
    {
        // параметры компонента
        $params = ComponentHelper::getParams('com_smaiwriter');
        $apiKey     = $params->get('api_key');
        $categoryId = (int) $params->get('category_id');
        $enableImg  = (int) $params->get('enable_images', 1);
        $enableMeta = (int) $params->get('enable_meta', 1);
        if (!$apiKey) {
            throw new \Exception('API ключ не указан');
        }

        // Генерация текста
        $text = $this->generateText($prompt, $apiKey);
        $text = $this->addReadMore($text);

        // Генерация изображения
        $image = '';
        if ($enableImg) {
            $imgBase64 = $this->generateImage($prompt, $apiKey);
            if ($imgBase64) {
                $image = ImageHelper::saveBase64($imgBase64);
            }
        }

        // Генерация meta
        $meta = ['title' => $prompt, 'desc' => ''];
        if ($enableMeta) {
            $meta = $this->generateMeta($text, $apiKey, $prompt);
        }

        // Создание материала
        return $this->createArticle($prompt, $text, $categoryId, $image, $meta);
    }

    /**
     * Генерация текста через AI Framework
     */
    private function generateText($prompt, $key)
    {
        $ai  = \Joomla\CMS\AI\AI::getInstance();
        $gen = $ai->getTextGenerator();
        $res = $gen->generate([
            'prompt'  => $prompt,
            'api_key' => $key,
            'model'   => 'yandexgpt-lite'
        ]);
        if (empty($res['text'])) {
            throw new \Exception('Модель вернула пустой текст');
        }
        LogHelper::add('text', 'success', 'Текст сгенерирован', $prompt);
        return trim($res['text']);
    }

    /**
     * Генерация изображения через AI Framework
     */
    private function generateImage($prompt, $key)
    {
        $ai  = \Joomla\CMS\AI\AI::getInstance();
        $gen = $ai->getImageGenerator();
        $res = $gen->generate([
            'prompt'  => $prompt,
            'api_key' => $key,
            'model'   => 'yandexgpt-art'
        ]);
        if (!isset($res['image']) || !$res['image']) {
            LogHelper::add('image', 'error', 'Изображение не получено', $prompt);
            return null;
        }
        LogHelper::add('image', 'success', 'Изображение создано', $prompt);
        return $res['image'];
    }

    /**
     * Генерация мета-тегов через AI Framework
     */
    private function generateMeta($text, $key, $topic)
    {
        $ai  = \Joomla\CMS\AI\AI::getInstance();
        $gen = $ai->getTextGenerator();
        $prompt = "Сделай SEO title и description\n" .
            "Тема: {$topic}\n" .
            "Текст:\n{$text}\n" .
            "Формат:\nTITLE: ...\nDESCRIPTION: ...";
        $res = $gen->generate([
            'prompt'  => $prompt,
            'api_key' => $key
        ]);
        return MetaHelper::parseMeta($res['text'] ?? '');
    }

    /**
     * Добавить тег ReadMore после первого абзаца
     */
    private function addReadMore($text)
    {
        if (preg_match('/(<p>.*?<\/p>)/si', $text, $m)) {
            // вставляем после первого абзаца
            return $m[1] . "\n<hr id='system-readmore'>\n" . str_replace($m[1], '', $text);
        }
        // если нет <p>, просто добавляем
        return "<hr id='system-readmore'>\n" . $text;
    }

    /**
     * Создать материал в com_content
     */
    private function createArticle($title, $text, $categoryId, $image, $meta)
    {
        // данные для сохранения
        $data = [
            'title'    => $meta['title'] ?: $title,
            'alias'    => StringHelper::slug($title),
            'introtext' => $text,
            'fulltext'  => '',
            'catid'     => $categoryId,
            'state'     => 1,
            'publish_up' => date('Y-m-d H:i:s'),
            'metadesc'  => $meta['desc'] ?? '',
            'images'    => json_encode([
                'image_intro'    => $image,
                'image_fulltext' => $image
            ])
        ];
        $table = Table::getInstance('Content');
        $table->save($data);
        LogHelper::add('article', 'success', 'Статья создана', $title);
        return $table->id;
    }
}