<?php

namespace Joomla\Component\Smaiwriter\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\ListModel;

/**
 * Модель для представления очереди задач
 */
class TasksModel extends ListModel
{
    /**
     * Построить SQL запрос к таблице задач
     *
     * @return \Joomla\Database\DatabaseQuery
     */
    protected function getListQuery()
    {
        $db    = $this->getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from('#__smaiwriter_prompts')
            ->order('id DESC');
        return $query;
    }
}