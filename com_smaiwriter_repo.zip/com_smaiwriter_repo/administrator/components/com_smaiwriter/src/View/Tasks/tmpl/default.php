<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 *
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

// Load progress via AJAX
?>
<h1><?php echo JText::_('COM_SMAIWRITER_TASKS_TITLE'); ?></h1>

<div class="progress" style="height: 30px; margin-bottom: 15px;">
    <div id="sm-progress" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;">
        0%
    </div>
</div>

<p>
    <?php echo JText::_('COM_SMAIWRITER_CURRENT_PROMPT'); ?> <strong id="sm-current">–</strong>
</p>

<script>
function updateProgress() {
    Joomla.request({
        url: 'index.php?option=com_smaiwriter&task=ajax.progress&format=json',
        method: 'GET',
        onSuccess: function (resp) {
            try {
                var d = JSON.parse(resp);
                document.getElementById('sm-progress').style.width = d.percent + '%';
                document.getElementById('sm-progress').innerHTML = d.percent + '%';
                document.getElementById('sm-current').innerHTML = d.current ? d.current : '–';
            } catch (e) {
                console.error(e);
            }
        }
    });
}
setInterval(updateProgress, 3000);
updateProgress();
</script>

<table class="table table-striped">
    <thead>
        <tr>
            <th><?php echo JText::_('JGLOBAL_ID'); ?></th>
            <th><?php echo JText::_('COM_SMAIWRITER_TASK_PROMPT'); ?></th>
            <th><?php echo JText::_('JSTATUS'); ?></th>
            <th><?php echo JText::_('COM_SMAIWRITER_TASK_MESSAGE'); ?></th>
            <th><?php echo JText::_('JDATE'); ?></th>
            <th><?php echo JText::_('JGRID_HEADING_ID'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($this->items as $item) : ?>
            <tr>
                <td><?php echo (int) $item->id; ?></td>
                <td><?php echo htmlspecialchars($item->prompt, ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($item->status, ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($item->message, ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($item->updated_at, ENT_QUOTES, 'UTF-8'); ?></td>
                <td>
                    <a class="btn btn-danger btn-sm" href="index.php?option=com_smaiwriter&task=tasks.skip&id=<?php echo (int) $item->id; ?>">
                        <?php echo JText::_('COM_SMAIWRITER_SKIP_TASK'); ?>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
