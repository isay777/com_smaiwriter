<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Smaiwriter\Administrator\View\Tasks;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

/**
 * View class to display the queue of generation tasks.
 */
class HtmlView extends BaseHtmlView
{
    /**
     * Array of task items
     *
     * @var  array
     */
    protected $items;

    /**
     * Display the tasks view.
     *
     * @param   string  $tpl  Template name
     *
     * @return  void
     */
    public function display($tpl = null)
    {
        $this->items = $this->get('Items');
        parent::display($tpl);
    }
}
