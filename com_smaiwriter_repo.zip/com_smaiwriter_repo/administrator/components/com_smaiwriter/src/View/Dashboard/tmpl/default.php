<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_smaiwriter
 *
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Simple dashboard with links to generate and view tasks
?>
<h1><?php echo JText::_('COM_SMAIWRITER'); ?></h1>

<p><?php echo JText::_('COM_SMAIWRITER_DASHBOARD_INTRO'); ?></p>

<div class="btn-toolbar">
    <div class="btn-group">
        <a class="btn btn-primary" href="index.php?option=com_smaiwriter&task=generate.run">
            <?php echo JText::_('COM_SMAIWRITER_RUN_GENERATION'); ?>
        </a>
    </div>
    <div class="btn-group">
        <a class="btn btn-secondary" href="index.php?option=com_smaiwriter&view=tasks">
            <?php echo JText::_('COM_SMAIWRITER_VIEW_TASKS'); ?>
        </a>
    </div>
</div>
