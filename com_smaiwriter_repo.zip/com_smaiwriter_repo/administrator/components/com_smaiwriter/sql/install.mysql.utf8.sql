CREATE TABLE IF NOT EXISTS `#__smaiwriter_prompts` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `prompt` TEXT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `message` TEXT DEFAULT NULL,
  `result_article_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `#__smaiwriter_logs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(50) NOT NULL,
  `status` VARCHAR(20) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `prompt` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;