DROP TABLE IF EXISTS `#__smaiwriter_prompts`;
DROP TABLE IF EXISTS `#__smaiwriter_logs`;