<?php
/**
 * Service provider for SM AI Writer.
 *
 * Регистрирует помощники (helpers) в DI контейнере Joomla.
 */

defined('_JEXEC') or die;

use Joomla\CMS\DI\Container;
use Joomla\CMS\DI\ServiceProviderInterface;

class SmaiwriterServiceProvider implements ServiceProviderInterface
{
    /**
     * Регистрация сервисов в контейнере
     *
     * @param Container $container
     * @return void
     */
    public function register(Container $container)
    {
        // Регистрация LogHelper
        $container->set(
            'Smaiwriter\\Helper\\LogHelper',
            function () {
                return new \Smaiwriter\Helper\LogHelper();
            }
        );

        // Регистрация QueueHelper
        $container->set(
            'Smaiwriter\\Helper\\QueueHelper',
            function () {
                return new \Smaiwriter\Helper\QueueHelper();
            }
        );

        // Регистрация ImageHelper
        $container->set(
            'Smaiwriter\\Helper\\ImageHelper',
            function () {
                return new \Smaiwriter\Helper\ImageHelper();
            }
        );

        // Регистрация MetaHelper
        $container->set(
            'Smaiwriter\\Helper\\MetaHelper',
            function () {
                return new \Smaiwriter\Helper\MetaHelper();
            }
        );
    }
}