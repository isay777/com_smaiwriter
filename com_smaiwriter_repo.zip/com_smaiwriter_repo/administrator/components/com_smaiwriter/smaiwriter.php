<?php
/**
 * SM AI Writer entry point.
 *
 * Этот файл создаёт экземпляр контроллера компонента и передаёт управление
 * исходя из переданного параметра `task`.
 */

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;

$controller = BaseController::getInstance('Smaiwriter');
$app        = Factory::getApplication();
$input      = $app->input;
$task       = $input->getCmd('task', 'display');
$controller->execute($task);
$controller->redirect();