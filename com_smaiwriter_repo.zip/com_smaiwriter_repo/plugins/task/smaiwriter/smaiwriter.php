<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Task.smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;

/**
 * Task scheduler plugin to trigger AI generation queue.
 */
class PlgTaskSmaiwriter extends CMSPlugin
{
    /**
     * Execute the task.
     *
     * @param   integer  $taskId  The ID of the task being executed
     * @param   object   $task    An object describing the task options
     *
     * @return  boolean  True on success
     */
    public function onExecuteTask($taskId, $task)
    {
        // Boot the component and run a batch of tasks
        $model = Factory::getApplication()
            ->bootComponent('com_smaiwriter')
            ->getMVCFactory()
            ->createModel('Generate', 'Administrator');

        $model->generateBatch(3);
        return true;
    }

    /**
     * Provide task options to the scheduler list.
     *
     * @param   array  &$list  The list of tasks
     *
     * @return  void
     */
    public function onTaskOptionsList(&$list)
    {
        $list[] = [
            'value' => 'smaiwriter',
            'text'  => 'SM AI Writer — генерация статей'
        ];
    }
}
