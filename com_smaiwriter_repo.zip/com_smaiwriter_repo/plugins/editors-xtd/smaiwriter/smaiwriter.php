<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Editors-xtd.smaiwriter
 * @copyright   Copyright (C) 2025 Your Company.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

/**
 * Button plugin to insert AI generated articles from the editor.
 */
class PlgEditorsXtdSmaiwriter extends CMSPlugin
{
    /**
     * Display the AI button in the editor toolbar.
     *
     * @param   string  $editor  Editor identifier
     * @param   string  $name    The name of the editor field
     *
     * @return  string  HTML markup
     */
    public function onDisplay($editor, $name)
    {
        return '<button type="button" class="btn btn-success" onclick="SMGenerateAI()">AI</button>' .
            '<script src="/plugins/editors-xtd/smaiwriter/media/js/editor.js"></script>';
    }
}
